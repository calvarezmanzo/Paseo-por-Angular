export interface PersonaLinkedin {
    Nombre: string;
    Apellido: string;
    Linkedin: string;
}
