import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PersonaLinkedin } from 'src/app/interface/form';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  formularioEjemplo!:FormGroup;
  personas: PersonaLinkedin[] = [];
  
  constructor(
    private formBuilder: FormBuilder,
    private apiService: ApiService,
  ) { }

  ngOnInit(): void {
    this.formularioEjemplo = this.formBuilder.group({
      Nombre:['',[Validators.required,Validators.minLength(5)]],  
      Apellido:['',[Validators.required,Validators.minLength(10)]], 
      Linkedin:['',[Validators.required]], 
    })
    this.loadPersonas();
  }

  get f(){
    return this.formularioEjemplo.controls;
  }

  loadPersonas(){
    this.apiService.getData().subscribe((data)=>{
      this.personas=data.personas;
    })
  }

  onSubmit(){
    console.log(this.formularioEjemplo.value);
    
    if(this.formularioEjemplo.valid){
      const persona: PersonaLinkedin = this.formularioEjemplo.value as PersonaLinkedin;
      this.apiService.saveData(persona).subscribe((data)=>{
        this.loadPersonas()
      })
    }
    
    
  }

}
