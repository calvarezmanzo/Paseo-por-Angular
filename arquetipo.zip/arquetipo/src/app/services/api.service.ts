import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PersonaLinkedin } from '../interface/form';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private apiUrl = 'https://www.codigo-alfa.cl/aglo/Angular/';  // Reemplaza con tu URL

  constructor(private http: HttpClient) { }

  getData(): Observable<any> {
    return this.http.get<any>(this.apiUrl+'listPersona');
  }

  saveData(data: PersonaLinkedin): Observable<any> {
    return this.http.post<PersonaLinkedin>(this.apiUrl+'savePersona', data);
  }
}
