export const environment = {
  production: true,
  databaseuser:'root',
  databasepassword:'ioqwueiouqwe',
  databasehost:'www.bootcamp.cl',
};
